import './App.css'
import { NavigationMenuDemo } from './shared/components/Nav'

function App() {
  return (
    <>
      <NavigationMenuDemo/>
    </>
  )
}

export default App
