import { app } from "./src/app.js";
import { logger } from "./src/logger/logger.js";

app.listen(process.env.PORT, () => {
    logger.info(`Server is running on port: ${process.env.PORT}`)
})
