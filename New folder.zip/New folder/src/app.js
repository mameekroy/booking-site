import express from "express"
import dotenv from "dotenv"
import cors from "cors"
import { createDbConnection } from "./db/connection.js"
import { authRouter } from "./module/auth/route/auth-route.js"
import { hotelRouter } from "./module/hotel/route/hotel-route.js"
import { bookingRouter } from "./module/booking/route/booking-route.js"

dotenv.config()

export const app = express()

createDbConnection()

app.use(express.json())
app.use(cors())

app.use('/auth', authRouter)
app.use('/hotels', hotelRouter)
app.use('/booking', bookingRouter)
