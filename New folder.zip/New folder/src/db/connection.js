import mongoose from "mongoose"
import {logger} from "../logger/logger.js"

export const createDbConnection = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI)
        logger.info('Connection Established Successfully')
    } catch (error) {
        logger.error('Connection Not Established')
        console.log(error)
    }
}
