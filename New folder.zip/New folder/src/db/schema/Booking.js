import mongoose from "mongoose";

const bookingItemsSchema = new mongoose.Schema({
    hotel_id: {
        type: String,
        ref: 'hotels',
        required: true,
    },
    price: {
        type: String,     //Number
    },
});

const bookingSchema = new mongoose.Schema({
    booking_id: {
        type: String,
        required: true
    },
    user_id: {
        type: String,
        required: true,
        ref: 'users'
    },
    booking_items: [bookingItemsSchema],
    booking_price: {
        type: String
    },
    is_deleted: {
        type: Boolean,
        default: false
    }
})

export const Booking = new mongoose.model('bookings', bookingSchema)
