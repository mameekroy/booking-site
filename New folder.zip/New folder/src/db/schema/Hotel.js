import mongoose from "mongoose";

const hotelSchema = mongoose.Schema({
    hotel_id: {
        type: String,
        required: true
    },
    hotel_title: {
        type: String,
        required: true
    },
    hotel_description: {
        type: String,
        required: true
    },
    hotel_image: {
        type: String,
        required: true
    },
    hotel_price: {
        type: String,
        required: true
    }
})

export const Hotel = mongoose.model('hotels', hotelSchema)
