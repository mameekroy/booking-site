import { v4 as uuidv4 } from 'uuid';
import { signUpSchema } from '../validator/signUpValidator.js';
import { logger } from '../../../logger/logger.js';
import { User } from '../../../db/schema/User.js';
import { signInSchema } from '../validator/signInValidator.js';
import { comparePassword, hashPassword } from '../util/password.js';
import { generateToken } from '../util/jwt.js';

export const signUp = async (req, res) => {
    try {
        const body = req.body
        // console.log(body)
        // res.json(body)
        const {error, value} = signUpSchema.validate(body)
        const {phone} = value
        // console.log(value)
        // console.log({phone})

        const isExisting = await User.findOne({ phone })
        if(isExisting){
            res.status(409).json({ message: "User already exists" })
            throw new Error('User Already Exists')
        }

        const userId = uuidv4()
        const hashedPassword = hashPassword(value.password)
        const user = new User({
            user_id: userId,
            role: value.role,
            user_name: value.user_name,
            phone: value.phone,
            password: hashedPassword
        })
        // console.log(user)
        await user.save()

        logger.info(`User Created Successfully with id ${userId}`)
        res.status(201).json(user)
    } catch (error) {
        logger.error('Error in signup')
        console.log(error)
    }
}

export const signIn = async (req, res) => {
    try {
        const body = req.body
        // console.log(body)
        // res.json(body)
        const {error, value} = signInSchema.validate(body)
        const {phone} = value
        // console.log({phone})

        const user = await User.findOne({phone})
        if(!user){
            res.status(404).json({message: 'User Not Found'})
            throw new Error('User Not Found')
        }

        const matchPassword = comparePassword(value.password, user.password)
        if(!matchPassword){
            throw new Error('Invalid phone number or password')
        }

        const token = generateToken(user.user_id)

        logger.info(`Login successful of user with id ${user.user_id}`)
        res.status(200).json({ message: 'Login Successful', user, token: token })
    } catch (error) {
        logger.error('Error in signin')
        console.log(error)
    }
}
