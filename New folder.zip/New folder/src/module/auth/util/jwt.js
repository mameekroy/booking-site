import jwt from "jsonwebtoken"
import { logger } from "../../../logger/logger.js"

export const generateToken = (userid) => {
    try {
        const token = jwt.sign({userid}, process.env.JWT_SECRET, {expiresIn: '10h'})
        return token
    } catch (error) {
        logger.error('Error in token generation')
        console.log(error)
    }
}

export const verifyToken = (token) => {
    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET)
        return decoded
    } catch (error) {
        logger.error('Error in token verification')
        console.log(error)
    }
}
