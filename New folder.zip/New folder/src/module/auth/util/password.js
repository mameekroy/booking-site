import bcrypt from "bcrypt";
import { logger } from "../../../logger/logger.js";

export const hashPassword = (rawPassword) => {
    try {
        const hashPassword = bcrypt.hashSync(rawPassword, 10)
        return hashPassword
    } catch (error) {
        logger.error("Error in Password Hashing")
        console.log(error)
    }
};

export const comparePassword = (rawPassword, hashedPassword) => {
    return bcrypt.compareSync(rawPassword, hashedPassword)
};
