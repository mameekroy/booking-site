import Joi from "joi";

export const signUpSchema = Joi.object({
    role: Joi.string().required(),
    user_name: Joi.string().required(),
    phone: Joi.string().required(),
    password: Joi.string().required()
})
