import { logger } from "../../../logger/logger.js"
import { bookingService } from "../service/booking-service.js"

export const addToBooking = async (req, res) => {
    try {
        const { userid } = req.user;
        const { body } = req;
        const booking = await bookingService.addToBooking(userid, body.hotel_id)
        res.status(200).json(booking)
    } catch (error) {
        logger.error('Error in add to booking in booking-controller')
        console.log(error)
    }
}


export const getBookingByUserId = async (req, res) => {
    try {
        const { userid } = req.user
        const booking = await bookingService.getBookingByUserId(userid)
        res.status(200).json({ message: 'Get Success' }, booking)
    } catch (error) {
        logger.error('Error in getting booking by userid in booking-controller')
        console.log(error)
    }
}
