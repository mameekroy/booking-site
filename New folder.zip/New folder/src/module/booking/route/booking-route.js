import { Router } from "express";
import { addToBooking, getBookingByUserId } from "../controller/booking-controller.js";
import { authMiddleware } from "../../auth/middleware/auth-middleware.js";

export const bookingRouter = Router()

// bookingRouter.get('/', )

bookingRouter.get('/', authMiddleware, getBookingByUserId)

bookingRouter.post('/', authMiddleware, addToBooking)


