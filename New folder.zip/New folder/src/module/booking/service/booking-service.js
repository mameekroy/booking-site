import { Booking } from "../../../db/schema/Booking.js"
import { logger } from "../../../logger/logger.js"
import { hotelService } from "../../hotel/service/hotel-service.js"
import { v4 as uuidv4 } from 'uuid'

export const bookingService = {
    async getBookingByUserId(id) {
        try {
            const booking = await Booking.aggregate([
                {
                    $match: {
                        user_id: id,
                        is_deleted: false
                    },
                },
                {
                    $sort: {
                        _id: -1,
                    },
                },
                {
                    $lookup: {
                        from: "users",
                        localField: "user_id",
                        foreignField: "user_id",
                        as: "user_detail",
                    },
                },
                {
                    $lookup: {
                        from: "hotels",
                        localField: "booking_items.hotel_id",
                        foreignField: "hotel_id",
                        as: "hotels",
                    },
                },
            ])
            console.log('Data before sending ', booking)
        } catch (error) {
            logger.error('Error in getting booking by userid in booking-service')
            console.log(error)
        }
    },

    async addToBooking(userid, hotelId) {
        try {
            let booking = await this.getBookingByUserId(userid)
            const hotel = await hotelService.getHotelByHotelId(hotelId)

            if (!booking) {
                const bookingId = uuidv4()

                booking = new Booking({
                    user_id: userid,
                    booking_id: bookingId,
                    booking_items: [
                        {
                            hotel_id: hotelId,
                            price: Number(hotel.hotel_price),
                        },
                    ],
                    isDeleted: false,
                    booking_price: Number(hotel.hotel_price)
                })

                await booking.save()
            } else {
                const hotelIndex = booking.booking_items.findIndex(
                    (hotel) => hotel.hotel_id === hotelId
                )

                if (hotelIndex === -1) {
                    booking.booking_items.push({
                        hotel_id: hotelId,
                        price: Number(hotel.hotel_price),
                    })
                    booking.booking_price += Number(hotel.hotel_price)
                } else {
                    booking.booking_items[hotelIndex].price *= 1
                }
            }

            // console.log("The final booking is here", booking)

            if (booking._id) {
                await Booking.findByIdAndUpdate(booking._id, {
                    booking_items: booking.booking_items,
                    booking_price: booking.booking_price,
                })
            }

            return booking
        } catch (error) {
            logger.error('Error in add to booking in booking-service')
            console.log(error)
        }
    }
}