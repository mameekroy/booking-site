import { Hotel } from "../../../db/schema/Hotel.js"
import { logger } from "../../../logger/logger.js"
import { hotelSchema } from "../validator/hotel-validator.js"
import { v4 as uuidv4 } from "uuid"

export const getAllHotels = async (req, res) => {
    try {
        const hotels = await Hotel.find()
        if (!hotels) {
            res.status(404).json({ message: 'Hotels Not Found' })
            throw new Error('Hotels not found')
        }
        res.status(201).json(hotels)
    } catch (error) {
        logger.error('Error in getting hotels')
        console.log(error)
    }
}

export const addHotel = async (req, res) => {
    try {
        const body = req.body
        const { error, value } = hotelSchema.validate(body)

        const hotelId = uuidv4()

        const hotel = new Hotel({
            hotel_id: hotelId,
            hotel_title: value.title,
            hotel_description: value.description,
            hotel_image: value.image,
            hotel_price: value.price
        })

        await hotel.save()

        logger.info(`Product Added Successfully with id ${hotelId}`)
        res.status(201).json(hotel)
    } catch (error) {
        logger.error('Error in adding product')
        console.log(error)
    }
}
