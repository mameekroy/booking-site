import { Router } from "express";
import { addHotel, getAllHotels } from "../controller/hotel-controller.js";
import { authMiddleware } from "../../auth/middleware/auth-middleware.js";

export const hotelRouter = Router()

hotelRouter.get('/', getAllHotels)

hotelRouter.post('/addhotel', authMiddleware, addHotel)  


