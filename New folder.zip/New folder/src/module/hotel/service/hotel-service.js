import { Hotel } from "../../../db/schema/Hotel.js";

export const hotelService = {

  async getHotelByHotelId(id) {
    const hotel = await Hotel.findOne({ hotel_id: id })
    console.log(hotel)
    if (!hotel) {
      throw new Error("Hotel not Found")
    }
    return hotel;
  }
  
};
